package Java;

public class MovieTicket {
     static int seats=250;
        static int hall;
    public static void main(String[] args) {
        MovieTicket sc =new MovieTicket();
        sc.seatAvailability();
    }

        public void seatAvailability(){
            while (seats!=0) {
                
            if(seats!=0){
                System.out.println("Your seat is allocated");
                seats-=1;
            }
            else{   
                System.out.println("Seat not available");
            }
        
        }

        }
    }

