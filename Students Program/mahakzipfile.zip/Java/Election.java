package Java;

import java.util.Scanner;

public class Election {
    public static void main(String[] args) {
        int bjpCount =0, cngCount=0, spCount=0, nota=0, age;
        Scanner sc = new Scanner(System.in);
        while (true) {
          System.out.println("Enter your Age : "); 
          age = sc.nextInt();
          if (age>=18 && age<120) {
            System.out.println("Welcome to Online Election System !");
            System.out.println("Enter 1 for BJP\nEnter 2 for Congress\nEnter 3 for Samajwadi Party\nEnter 4 for NOTA\nEnter 5 for Exit...");
            int opt = sc.nextInt();
            if(opt==1){
                System.out.println("Voted for BJP");
                bjpCount+=1;
            }
            else if (opt==2){
                System.out.println("Voted for Congress");
                cngCount+=1;
            }
           else if (opt==3){
                System.out.println("Voted for Samajwadi Party");
                spCount+=1;
            }
            else if (opt==4){
                System.out.println("Voted for NOTA");
                nota+=1;
            }
            else if (opt==5){
                System.out.println("Thanks for Visiting");
                break;
            }
            else {
                System.out.println("Invalid Vote");
            }
          } 
          else
          {
            System.out.println("Invalid Age..\nYou are unable to vote.");
          }

        }
        System.out.println("Total BJP votes :"+bjpCount);
        System.out.println("Total Congree votes :"+cngCount);
        System.out.println("Total Samajwadi Party votes :"+spCount);
        System.out.println("Total NOTA votes :"+nota);
        sc.close();
    }
}
