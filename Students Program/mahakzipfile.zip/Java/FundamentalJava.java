package Java;

import java.util.Scanner;

public class FundamentalJava {
static Scanner sc = new Scanner(System.in);
int num;
    public void inp(){
        System.out.println("Enter a number : ");
        num = sc.nextInt();
    }

    public void table(){
        System.out.println(" Table till 5 are ");
        for(int i =1; i<=5 ; i++){
            System.out.println("Table of "+i +" is : ");
            for( int j=1; j<=10; j++){
                System.out.println(i*j);
            }
        }
    }
    public void evenOdd(){
        int countEven =0;
        int countOdd =0;

        for(int i = 1 ; i<=num ; i++){
            if(i % 2 == 0){
               countEven += 1;   
        }
        else{
            countOdd +=1;
        }

    }
        System.out.println("Number of Even numbers till "+ num + " are : "+ countEven);
        System.out.println("Number of odd numbers till "+ num + " are : "+ countOdd);
}

    public void showOddTables(){
        System.out.println("Table of Odd Numbers till "+num + " are : ");
        for( int i =1; i<= num ; i+=2){
            System.out.println("Table of "+i+ " is : ");
            for( int j =1; j<=10 ;j++){
                System.out.println(j*i);
            }


            }
        }

        public void showEvenTables(){
        System.out.println("Table of Even Numbers till "+num + " are : ");
        for( int i =2; i<= num ; i+=2){
            System.out.println("Table of "+i+ " is : ");
            for( int j =1; j<=10 ;j++){
                System.out.println(j*i);
            }


            }
        }
        public void factorial() {
            int fact = 1;
            System.out.println("Factorials till "+ num + " are : " );
            for ( int i =1 ; i<=num ;i++){
                System.out.println("Factorial of" +i+ " is : ");
                {
                    for( int j =1 ; j<=i ; j++){
                        fact= fact*j;
                    }
                    System.out.println(fact);
                    fact=1;
                }
            }            
        }

        public void checkPrime(){      
                int flag =0;
                int midNum = num/2;
                for (int i = 2; i<=midNum ; i++){
                if( num % i ==0 ){
                System.out.println(num + " is Not a prime number.");
                flag=1;
                break;
            }
            }
             if (flag==0) {
                System.out.println(num + " is Prime number. ");                
             }
        }

        public void showPrimes(){
            System.out.println("Prime number till "+num+ " are : ");
            
                
                for (int i = 2; i<=num ; i++){
                   
                    boolean isprime = true;
                    for ( int j =2; j<=i/2; j++){
                        if(i%j ==0){
                            isprime=false;
                            break;
                        }
                        
                    }
                    if(isprime){
                        System.out.println(i);
                    }
                   }
    }
    public static void main(String[] args) {
        FundamentalJava obj = new FundamentalJava();
       // obj.table();
        obj.inp();
       // obj.evenOdd();
       // obj.showEvenTables();
       // obj.showOddTables();
        //obj.factorial();
        //obj.checkPrime();
        obj.showPrimes();

    }
    
    

}
