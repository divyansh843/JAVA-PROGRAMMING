/*
 * Take the salary of user as input then apply tax accordingly.
 */
package Java;

import java.util.Scanner;

public class ApplyTax {
   public static double salary;
   public static double tax;
    
   public void inpSal(){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter your Salary : ");
    salary= sc.nextDouble();
    sc.close();
    
    
   }

   public void applyTax(){
    if(salary<=50000){
        System.out.println("No tax ");
        
    }
    else if(salary>50000 && salary<=100000){
        tax=salary*(.1);
        System.out.println("Tax is 10% : "+tax);
    }
    else if(salary>100000 && salary<=200000){
        tax=salary*(.15);
        System.out.println("Tax is 15% : "+tax);
   }
   
    else{
        tax= salary*(.20);
        System.out.println("Tax is 20% : "+tax);
    }
   }
public static void main(String[] args) {
    ApplyTax obj = new ApplyTax();
    obj.inpSal();
    obj.applyTax();
    
}
}