                                                                            //  passing current object as arguments //
 class passingobject {
    String location;

     passingobject(String location) {
        this.location=location;
    }
    void assigndriver(driver d){
        d.pickOrder(this);
    }

    
}
public class driver{
    void pickOrder(passingobject d){
        System.out.println("driver assigned for delivery is from  " + d.location);
    }
    public static void main(String[] args) {
        passingobject p=new passingobject("kanpur");
        driver driver =new driver();
        p.assigndriver(driver);
    }
}

