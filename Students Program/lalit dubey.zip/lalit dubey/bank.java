public class bank{
    String account;
    double balance;
      bank(String account,double balance){
        this. account=account;
         this.balance=balance;
      }
      void disp(){
           System.out.println("account :"+account);
        System.out.println("balnce :"+balance);
      }
    
public static void main(String[] args) {
    bank b=new bank( "lalit dubey",5000);
    b.disp();
}
}
