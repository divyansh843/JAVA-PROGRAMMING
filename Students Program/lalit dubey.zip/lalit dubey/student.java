public class student {
    int marks1,marks2,marks3;

  student(int m1,int m2,int m3){
    this.marks1=m1;
    this.marks2=m2;
    this.marks3=m3;

  }
   void disp(){
    int avg =(marks1+marks2+marks3)/3;
    System.out.println("average " + avg);
   }
    public static void main(String[] args) {
        student s=new student(5,47,45);
        s.disp();
    }
}
