public class methodchaining {
String name;
int age;
String city;
 methodchaining setName(String name){
    this.name=name;
    return this;
 }
 methodchaining setAge(int age){
    this.age=age;
    return this;
 }
 methodchaining setCity(String city){
    this.city=city;
    return this;
 }
 void show(){
    System.out.println(name+ "  "+ "("+age +")," + "  " +  city);
 }
 public static void main(String[] args) {
    methodchaining p = new methodchaining();
    p.setName("Lalit") .setAge(22) .setCity("Kanpur") .show();
    
 }


}
