public class elecltricitybill{
  void caculatebill(int units){
    double costperunit=6.634;
    double total =units * costperunit;
    System.out.println("toal bill is "+ total);

  }
  public static void main(String[] args) {
    elecltricitybill e = new elecltricitybill();
       e.caculatebill(70);

  }
}