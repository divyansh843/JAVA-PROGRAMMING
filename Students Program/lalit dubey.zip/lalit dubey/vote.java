public class vote {
    int java;
    int css;
    int js;

     vote( int java,int css,int js) {
        this.java=java;
        this.css=css;
        this.js=js;
    }
    void disp(){
    if(java>css && java>js){System.out.println("java has more student");}
        else if(css>js&& java <js){
            System.out.println("css has more student");
        }
        else if(java == css|| java ==js||js==css){
        System.out.println("value should not be equal");
        }
        else {
           System.out.println( "js has more student");
        }
    }
    public static void main(String[] args) {
        vote v=new vote(52,50,51);
         v.disp();     
    }
}
