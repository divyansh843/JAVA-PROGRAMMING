public class anujsir {
    
    int duration;

     anujsir(int duration) {
       this.duration=duration;
    }
    void disp(){
        String total=(duration<=15) ? "course completed on time" : "course didn'nt completed on time";
      System.out.println(total);
    }
    public static void main(String[] args) {
        anujsir a= new anujsir(14);
        a.disp();
    }
    
}
