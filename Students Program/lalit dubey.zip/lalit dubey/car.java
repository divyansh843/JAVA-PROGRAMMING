public class car {
    String model;
    int x;
    car(String model,int x){
        this.model=model;
        this.x=x;

    }
    void disp(){
        System.out.println("model:"+ model);
        System.out.println("price :"+x);
    }
 public static void main(String[] args) {
    car c=new car("maruti",600000);
    c.disp();
 }   
}
