public class movieticket {
    String name;
    int price;

     movieticket(String name,int price) {
        this.name=name;
        this.price=price;
    }
    void disp(int quty){
        System.out.println("movie name is "+name);
        System.out.println("tickets "+quty);
        System.out.println("total bill is " +quty*price);
    }
    public static void main(String[] args) {
        movieticket m= new  movieticket("inception",400);
        m.disp(5);
    }
}
