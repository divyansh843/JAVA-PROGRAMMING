public class Hotelbooking {
    double price;
    int room;

     Hotelbooking( double  price,int room) {
        this.price=price;
        this.room=room;

    }
    void disp(){
        System.out.println("price is "+price+ " for room  "+room);
    }
  public static void main(String[] args) {
    Hotelbooking h=new Hotelbooking(6000.78,45);
    h.disp();
  }    
}
