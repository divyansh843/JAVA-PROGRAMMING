public class employbonus {
    String name;
    double salary;
    int experience;

    public employbonus( String name,double salary,int experience) {
        this.name=name;
        this.salary=salary;
        this.experience=experience;
    }
    void disp(){
        double bonus= (experience>5)? salary*0.1:salary*0.05;
        System.out.println("bonus is "+ bonus);
    }
    public static void main(String[] args) {
        employbonus e = new employbonus( "lalit dubey",52000,7);
        e.disp();
    }
}
