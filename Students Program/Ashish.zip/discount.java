public class discount {
    void discount(double amount){
    double discount=(amount>5000)?amount*0.10:amount*0.5;
    System.out.println("applied discount"+discount);
    }
    public static void main(String[] args) {
        discount d = new discount();
        d.discount(456400);
    }
}
