public class Holiday {

    String reason ;

    int days ;

    String significance;
  
    double spent;


    void setHolidayDetails(String reason, int days, String significance)
    {
        this.reason=reason;
        this.days=days;
        this.significance=significance;
        System.out.println("Holiday details set successfully..");

    }

    void getDetails()
    
    {
    
        System.out.println("Holiday details are : ");
    
        System.out.println("\nReason is:"+reason);
    
        System.out.println("Number of days of holiday is : "+days);
    
        System.out.println("Significance of this reason is : "+significance);
    }

    void addExpenses(double amount,String reason){
     
        spent+=amount;

     
        System.out.println("Spent Rs." + amount + " on " + reason);
     
     
        System.out.println("Total Expenses : "+spent);
    }
      

     
    public static void main(String[] args) {
    
        Holiday ob =new Holiday();
    
        ob.setHolidayDetails("Diwali",7,"Major Festival of India");
    
        ob.getDetails();
    
        ob.addExpenses(250.0, "Purchasing clothes");
    
    }

    


    

    
    
}
