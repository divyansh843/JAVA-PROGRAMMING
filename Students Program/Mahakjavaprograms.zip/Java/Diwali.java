import java.util.Scanner;

public class Diwali 
{


    String date;
    String location;
    String theme;
    String poojaTime;
    int numOfGuests;
    int diyaLit;
    int crackersBurst;
    int sweetsVariety;
    int giftReceived;
    double totalBudget;
    double spentAmount;




    Diwali(String date,String location, 
    String theme , String poojaTime, double totalBudget){
        this.date= date;
        this.location=location;
        this.theme=theme;
        this.poojaTime=poojaTime;
        this.numOfGuests=0;
        this.diyaLit=0;
        this.crackersBurst=0;
        this.sweetsVariety=0;
        this.giftReceived=0;
        this.totalBudget=totalBudget;
        this.spentAmount=0.0;
    }

    public void giveDetails(){
        System.out.println("Date of Diwali is : "+date);
        System.out.println("Location of Diwali Celebration is : "+location);
        System.out.println("Diwali Celebration theme is : "+ theme);
        System.out.println("Pooja Timing is : "+poojaTime);
        
    }


    void decorateHouse()
    {

        System.out.println("The House decorated beautifully with lights , flowers and Rangoli. \nMahak has made a beautiful Rangoli... \n ");
    }

    void lightDiyas(int diyas){


        diyaLit=diyaLit+diyas;
        System.out.println(" You lit "+diyas+" Diyas. \n Total diyas lit : "+diyaLit);
    
    }

    void addGuests(int guests)
    {
        numOfGuests+=guests;
        System.out.println(guests+" added !\n Total number of guests : "+numOfGuests);
    }

    void amountSpend(double amount, String purpose)
    {
        spentAmount+=amount;
        System.out.println(amount+" spend on "+purpose+"\nTotal expenditure is : "+spentAmount);
    }

    void checkBudget(){
       double remaining = totalBudget- spentAmount;
       System.out.println("Total Budget is : "+totalBudget);
       System.out.println("Money Spend : "+spentAmount);
       System.out.println("Remaining budget : "+remaining);
    }

    void greet()
    {
        System.out.println("Wishing you and your family a very Happy and Prosperous Diwali!");
    }

    void crackerLit(int crackers)
    {
        crackersBurst+=crackers;
        System.out.println("Recently you have burst "+crackers+ " crackers.");
        System.out.println("Total number of Crackers burst in this Deepawali celebration is :"+crackersBurst);

    }

    void sweetsReceived(int sweets)
    {
        sweetsVariety+=sweets;
        System.out.println(sweets+" more Sweets Added! \n Total number of sweets Received : "+sweetsVariety);
    }

    void giftsReceived(int gifts)
    {
        giftReceived+=gifts;
        System.out.println(gifts+" received recently \n Total number of gifts received is :"+giftReceived);
    }



public class DiwaliPlanner 
{
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);

        System.out.println("Welcome to Diwali Celebration Planner ");
        System.out.println("Enter Celebration Date (e.g . 20 Oct 2025 ): ");
        String date = sc.nextLine();
        System.out.println("Enter Location : ");
        String location = sc.nextLine();
        System.out.println("Enter Theme : ");
        String theme = sc.nextLine();
        System.out.println("Enter Pooja Timing : ");
        String poojaTime=sc.nextLine();
        System.out.println("Enter Total Budget : ");
        double totalBudget = sc.nextDouble();

        Diwali d =new Diwali(date, location, theme, poojaTime,totalBudget);

        int choice;

        do{
            System.out.println("        Menu :        ");
            System.out.println("1. Give Details");
            System.out.println("2. Decorate House ");
            System.out.println("3. Light Diyas");
            System.out.println("4. Add Guests");
            System.out.println("5. Know Expenditure");
            System.out.println("6. Check Budget");
            System.out.println("7. Greetings");
            System.out.println("8. Number of Crackers Burst");
            System.out.println("9. Sweets Received ");
            System.out.println("10. Gifts Received");
            System.out.println("0. Exit..");

            System.out.println("");
            System.out.println("Enter your Choice : ");
            choice=sc.nextInt();




             switch (choice) {
                case 1:
                    d.giveDetails();
                    break;
                case 2 :
                    d.decorateHouse();
                case 3:
                    System.out.print("Enter number of diyas to light: ");
                    int diyas = sc.nextInt();
                    d.lightDiyas(diyas);
                    break;
                case 4:
                    System.out.print("Enter number of guests to add: ");
                    int guests = sc.nextInt();
                    d.addGuests(guests);
                    break;
                case 5:
                    System.out.print("Enter amount you spend: Rs. ");
                    double amount = sc.nextDouble();
                    sc.nextLine(); // consume newline
                    System.out.print("Enter purpose: ");
                    String purpose = sc.nextLine();
                    d.amountSpend(amount, purpose);
                    break;
                case 6:
                    d.checkBudget();
                    break;
                case 7:
                    d.greet();
                    break;
                case 8:
                    System.out.println("Enter number of Crackers you burnt :");
                    int crackers=sc.nextInt();
                    d.crackerLit(crackers);
                    break;
                case 9:
                    System.out.println("Enter number of Sweets Received :");
                    int sweets=sc.nextInt();
                    d.sweetsReceived(sweets);
                    break;
                case 10:
                    System.out.println("Enter number of Gifts Received :");
                    int gifts=sc.nextInt();
                    d.giftsReceived(gifts);
                    break;
                case 0:
                    System.out.println("Exiting... Have a joyous Diwali! ");
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }



        }while(choice!=0);

        sc.close();

    }
}
}