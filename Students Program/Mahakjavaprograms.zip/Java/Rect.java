

public class Rect {
    private int l,b;
    void setData(int x, int y)
{
    l=x;
    b=y;

}
    public void area(){
        int a =l*b;
        System.out.println("Area is "+a);
    }
}
class Test{
    public static void main(String[] args) {
        Rect r=new Rect();
        r.setData(2,5);
        r.area();
    }
}
