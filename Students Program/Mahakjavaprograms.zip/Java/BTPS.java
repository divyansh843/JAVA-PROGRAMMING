import java.util.Scanner;

public class BTPS 
{
    static Scanner sc =new Scanner(System.in);
    String address;
    long contact;
    String companyType;
    double fees;


    BTPS()
    
    {
        address= "Crossing No. 9, Geeta Nagar , Kanpur";
        contact= 9044900033L ;
        companyType= "Education";
        fees= 40000.0;


    }

    void showDetails()
    {
        System.out.println("Welcome to BTPS ");
        System.out.println("Our Address is : "+address);
        System.out.println("Our Contact is : "+contact);
        System.out.println("Our Company type is : "+companyType);
    }

    void chooseCourse(){
        
        int choose;
        do{
            System.out.println("   Our Courses :        ");
            System.out.println("1. Full Stack with Java ");
            System.out.println("2. Full Stack with DotNet ");
            System.out.println("3. Full Stack with Python");
            System.out.println("4. Frontend Development");
            System.out.println("0. Exit..");

            System.out.println("");
            System.out.println("Enter your Choice : ");
            choose=sc.nextInt();

            switch (choose) {
                case 1:
                    javaDetails();
                    break;
                case 2:
                    dotnetDetails();
                    break;
                case 3 :
                    pythonDetails();
                    break;
                case 4 :
                    frontendDetails();
                    break;
                case 0 :
                     System.out.println("Exiting from Course Details.. ");
                     break;
                
                     
            
                default:
                    System.out.println("Invalid ");
                    
            }
        
        
        }while(choose!=0);
    }

       public void javaDetails(){
            System.out.println("Course Name : Full Stack With Java ");
            System.out.println("Duration : 6 months");
            System.out.println("Fees : "+fees);

        }

        public void pythonDetails(){
            System.out.println("Course Name : Full Stack With Python ");
            System.out.println("Duration : 6 months");
            System.out.println("Fees : "+fees);

        }
        public void dotnetDetails(){
            System.out.println("Course Name : Full Stack With DotNet ");
            System.out.println("Duration : 6 months");
            System.out.println("Fees : "+fees);

        }
        public void frontendDetails(){
            System.out.println("Course Name : Frontend Development ");
            System.out.println("Duration : 6 months");
            System.out.println("Fees : "+fees);

        }

        void diwaliOffer(){
            System.out.println("Wishing you a very Happy Diwali ");
            System.out.println(" BTPS offers you 20% off in each courses.");
            double offerPrice= fees-(fees*.2);
            System.out.println(" Diwali offer fees is "+ offerPrice);
        }



        public static void main(String[] args) {
            BTPS obj = new BTPS();
            obj.showDetails();

            obj.diwaliOffer();

            obj.chooseCourse();

            

        }

    }

