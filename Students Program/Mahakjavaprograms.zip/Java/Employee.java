/*
Write a java program having some attributes like id,name,age.
Then displat message from method .
Design one parameterised method given the salary . 
Check the condition , if age is 22 to 30 , then salary is 50000.
And if above 30, then salary is above 50000. 
*/

import java.util.*;

public class Employee {
    static Scanner sc = new Scanner(System.in);
    public  int id;
    public  String name;
    public  int age;

    public void display(){
        System.out.println("Your ID is "+id+" .");
        System.out.println("Your Name is "+name+" .");
        System.out.println("Your Age is "+age+" .");
    }

    public void salary(){

       
        if(age<22){
            System.out.println("Invalid age");
        }
        else if(age<=22 && age < 30){
            System.out.println("Your Salary is 50000.");
        }
        else{
            System.out.println("Your Salary is above 50000.");
        }
    }

    public static void main(String[] args) {
        
        Employee ob = new Employee();
        
        System.out.println("Enter your ID : ");
        ob.id = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter your Name : ");
        ob.name = sc.nextLine();       
        System.out.println("Enter your Age : ");
        ob.age = sc.nextInt();

        ob.display();
        ob.salary(); 
        sc.close();
    }
 }
