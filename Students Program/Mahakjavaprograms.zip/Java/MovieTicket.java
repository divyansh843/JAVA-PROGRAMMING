public class MovieTicket 
{


    String movieName;
    String theaterName;
    String showTime;
    int seatNumber;
    double price;
    boolean isBooked;


MovieTicket(String movieName, String theaterName, String showTime, int seatNumber, double price)

{
        this.movieName = movieName;
        this.theaterName = theaterName;
        this.showTime = showTime;
        this.seatNumber = seatNumber;
        this.price = price;
        this.isBooked = false;
    }

    void bookTicket()
    
    {
        if (!isBooked)
        
        {
            isBooked = true;
            System.out.println("Ticket booked successfully for " + movieName + ", Seat: " + seatNumber);
        } 
        
        else
        
        {
            System.out.println("Ticket is already booked!");
        }
    }

    void cancelTicket() 
    
    {
        if (isBooked) 
        {
            isBooked = false;
            System.out.println("Ticket cancelled for "+ movieName +", Seat: "+seatNumber);
        }
         else 
         
         {
            System.out.println("Ticket is not booked yet!");
        }
    }


     void applyDiscount(double percent)
      {
        price -= (price * percent / 100);

        System.out.println("Price after " + percent + "% discount: Rs." + price);
    }



    void changeSeat(int newSeat) {
        if (isBooked)
        
        {
            System.out.println("Seat changed from " + seatNumber + " to " + newSeat);
            seatNumber = newSeat;
        } 
        
        else 
        {
            System.out.println("You need to book the ticket first!");
        }
    }

     void showTicketDetails() {
        System.out.println("\nTICKET DETAILS");
        System.out.println("Movie: " +movieName);
        System.out.println("Theater: " +theaterName);
        System.out.println("Show Time: " +showTime);
        System.out.println("Seat Number: " +seatNumber);
        System.out.println("Price: Rs." + price);
        System.out.println("Booked: " + (isBooked ? "Yes" : "No"));
    }


    boolean isAvailable() {
        return !isBooked;
    }



    public static void main(String[] args) {
        MovieTicket obj = new MovieTicket("Kantara : The Legend", "PVR Cinema", "1:30 PM", 12, 300);

        obj.showTicketDetails();

        obj.bookTicket();

        obj.changeSeat(15);

        obj.showTicketDetails();
        obj.applyDiscount(10.0);


        obj.cancelTicket();

        obj.showTicketDetails();
        obj.isAvailable();
    }
}
