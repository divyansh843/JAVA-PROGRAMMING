

public class InnerTest {
    public static void main(String[] args) {
        System.out.println(Inner.b);
        Inner.m2();
        Inner t=new Inner();
        System.out.println(t.a);
        t.m1();
}
}