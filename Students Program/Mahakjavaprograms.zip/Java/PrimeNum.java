

import java.util.Scanner;

public class PrimeNum {
    public static void main(String[] args) {
        int flag=0;
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter a Number : ");
        int num = sc.nextInt();

        if(num ==0 ||num==1){
            System.out.println(num +" is not a prime number");
        }

        else{
            int midNum = num/2;
            for (int i =2; i<=midNum; i++){
                if(num % i == 0){
                    System.out.println(num +" is not a prime number");
                    flag=1;
                    break;
                }
                
            }

        }

        if (flag==0) {
            System.out.println(num +" is a prime number");
        }
sc.close();
    }

    
}
