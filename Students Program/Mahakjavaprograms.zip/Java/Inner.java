/*
 * Static and Non Static Members
 */


public class Inner {
    public int a =10;
    public static int b=20;
    public void m1(){
        System.out.println("Non Static Method..");
    }
    public static void m2(){
        System.out.println("Static Method..");
    }
    
     public class InnerTest {
    public static void main(String[] args) {
        System.out.println(Inner.b);
        Inner.m2();
        Inner t=new Inner();
        System.out.println(t.a);
        t.m1();
}



}}

