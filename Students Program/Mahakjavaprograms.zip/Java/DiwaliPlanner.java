import java.util.*;
public class DiwaliPlanner 
{
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);

        System.out.println("Welcome to Diwali Celebration Planner ");
        System.out.println("Enter Celebration Date (e.g . 20 Oct 2025 ): ");
        String date = sc.nextLine();
        System.out.println("Enter Location : ");
        String location = sc.nextLine();
        System.out.println("Enter Theme : ");
        String theme = sc.nextLine();
        System.out.println("Enter Pooja Timing : ");
        String poojaTime=sc.nextLine();
        System.out.println("Enter Total Budget : ");
        double totalBudget = sc.nextDouble();

        Diwali d =new Diwali(date, location, theme, poojaTime,totalBudget);

        int choice;

        do{
            System.out.println("        Menu :        ");
            System.out.println("1. Give Details");
            System.out.println("2. Decorate House ");
            System.out.println("3. Light Diyas");
            System.out.println("4. Add Guests");
            System.out.println("5. Know Expenditure");
            System.out.println("6. Check Budget");
            System.out.println("7. Greetings");
            System.out.println("8. Number of Crackers Burst");
            System.out.println("9. Sweets Received ");
            System.out.println("10. Gifts Received");
            System.out.println("0. Exit..");

            System.out.println("");
            System.out.println("Enter your Choice : ");
            choice=sc.nextInt();




             switch (choice) {
                case 1:
                    d.giveDetails();
                    break;
                case 2 :
                    d.decorateHouse();
                case 3:
                    System.out.print("Enter number of diyas to light: ");
                    int diyas = sc.nextInt();
                    d.lightDiyas(diyas);
                    break;
                case 4:
                    System.out.print("Enter number of guests to add: ");
                    int guests = sc.nextInt();
                    d.addGuests(guests);
                    break;
                case 5:
                    System.out.print("Enter amount you spend: Rs. ");
                    double amount = sc.nextDouble();
                    sc.nextLine(); // consume newline
                    System.out.print("Enter purpose: ");
                    String purpose = sc.nextLine();
                    d.amountSpend(amount, purpose);
                    break;
                case 6:
                    d.checkBudget();
                    break;
                case 7:
                    d.greet();
                    break;
                case 8:
                    System.out.println("Enter number of Crackers you burnt :");
                    int crackers=sc.nextInt();
                    d.crackerLit(crackers);
                    break;
                case 9:
                    System.out.println("Enter number of Sweets Received :");
                    int sweets=sc.nextInt();
                    d.sweetsReceived(sweets);
                    break;
                case 10:
                    System.out.println("Enter number of Gifts Received :");
                    int gifts=sc.nextInt();
                    d.giftsReceived(gifts);
                    break;
                case 0:
                    System.out.println("Exiting... Have a joyous Diwali! ");
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }



        }while(choice!=0);

        sc.close();

    }
}