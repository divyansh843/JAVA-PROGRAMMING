import java.util.Scanner;

public class Laptop 
{
    Scanner sc = new Scanner(System.in);
    String brand;
    String model;
    int ram;
    int storage;
    double price;
    double processorSpeed;

    Laptop(String brand, String model, int ram , int storage, 
    double price, double processorSpeed)
    {
        this.brand=brand;
        this.model=model;
        this.ram=ram;
        this.storage=storage;
        this.price=price;
        this.processorSpeed=processorSpeed;
    }
     
    public void showfeatures()
      {
        System.out.println("Brand of laptop is : "+brand);
        System.out.println("Model of laptop is : "+model);
        System.out.println("RAM is : "+ram+" GB");
        System.out.println("Storage is : "+storage+" GB");
        System.out.println("Price is : "+price+" Rs.");
        System.out.println("Processor Speed is : "+processorSpeed+" GHz");

}
     public boolean isCheaper(Laptop other )
     {
        return this.price< other.price;
        }


        public void applyDiscount(double percent)
        {
            price=price-(price*(percent/100));
            System.out.println("Discount Applied is :"+price);
        }


        public void upgradeRam(int extraRam)
        {
            ram=ram + extraRam;
            System.out.println("Now upgraded RAM is "+ram+" GB");
        }


        public void upgradeStorage(int extraStorage)
        {
            storage+=extraStorage;
            System.out.println("Now Upgraded Storage is "+storage+" GB");
        }


        public String performance()
        {
         double score = (ram*2)+(storage*.5)+ (processorSpeed*10);
         if(score>=800){
            return "High Performance";
         }    

         else if(score>=200){
         return "Medium Performance";
         }
         else{
            return "Low Performance";
         }


        }

        public static void main(String[] args) {
            
            Laptop l1 =new Laptop("Dell", 
            "Inspiron 14", 16, 256, 55000, 3.5);

            Laptop l2 = new Laptop("HP",
             "Pavilion 15", 28, 1024, 85000, 5.5);


             l1.showfeatures();

             l2.showfeatures();


             if(l1.isCheaper(l2)){

                System.out.println(l1.brand+" is cheaper than "+l2.brand);
             }
             else
             System.out.println(l2.brand+" is cheaper than "+l1.brand);


                l1.applyDiscount(10);



                l2.upgradeRam(4);
                l2.upgradeStorage(512);



                System.out.println(l1.performance());
                System.out.println(l2.performance());



        }

     }

  
