/*
 * Dual nature of double equals to Operator
 */


import java.util.Scanner;

public class Login {
    public static void main(String[] args) {
    String nm,pw;
    Scanner sc =new Scanner(System.in);
    System.out.println("Enter your name ");
    nm=sc.nextLine();
    System.out.println("Enter your password ");
    pw=sc.nextLine();
    if(nm.equals("Ram")&& pw.equals("Seeta")){
        System.out.println("Login Successfull ");
    }
    else{
        System.out.println("Invalid Login");
    }
sc.close();
}
}