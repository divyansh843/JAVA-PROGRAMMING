/*
 * Define a class Emp having attributes : empName,empCompName,empQualification,empPosition.
 * Then according to empPosition check salary . 
 */


import java.util.Scanner;




public class Emp {
    static Scanner sc =new Scanner(System.in);
    public String empName;
    public String empCompName;
    public String empQualification;
    public String empPosition ;

    public void show(){
        System.out.println("Employee's Name is "+empName);
     
        System.out.println("Employee's Company name  is "+empCompName);
     
        System.out.println("Employee's Qualification is "+empQualification);
     
        System.out.println("Employee's Position is "+empPosition);
    }

    public void takeData(){
        System.out.println("Enter Employee's name : ");
        empName=sc.nextLine();
        System.out.println("Enter Employee's Company name : ");
        empCompName=sc.nextLine();
        System.out.println("Enter Employee's Qualification : "); 
        empQualification=sc.nextLine();
        System.out.println("Enter Employee's Position (CEO, MD, BOD, Director, Manager, Supervisor or Operator) : ");
        empPosition=sc.nextLine();
    }

    public void checkSal(){
        if(empPosition.equalsIgnoreCase("CEO")){
            System.out.println(empPosition+"'s Salary is : "+250000);
        }
        else if (empPosition.equalsIgnoreCase("MD")){
            System.out.println(empPosition+"'s Salary is : "+150000);
        }
        else if (empPosition.equalsIgnoreCase("Director")){
            System.out.println(empPosition+"'s Salary is : "+100000);
        }
        else if (empPosition.equalsIgnoreCase("Manager")){
            System.out.println(empPosition+"'s Salary is : "+80000);
        }
        else if (empPosition.equalsIgnoreCase("Supervisor")){
            System.out.println(empPosition+"'s Salary is : "+48000);
        }
        else if
        (empPosition.equalsIgnoreCase("Worker"))
        {
            System.out.println(empPosition+"'s Salary is : "+20000);
        }
        else
        {
            System.out.println("This position does not exists.");
        }
    }
    public static void main(String[] args) 
    {
        Emp obj =new Emp();
        obj.takeData();
        obj.checkSal();
    }
    
}
