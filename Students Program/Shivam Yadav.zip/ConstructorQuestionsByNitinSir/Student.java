/*Write a Java program to create a class called Student with attributes name, rollNo,
and grade. Create a parameterized constructor to initialize these attributes and
display them. */
package ConstructorQuestionsByNitinSir;

public class Student {
    String name;
    double rollNo;
    String grade;

    Student(String name,double rollNo,String grade)
    {
        this.name=name;
        this.rollNo=rollNo;
        this.grade=grade;
    }
    void viewDetails()
    {
        System.out.println("Student name is:"+name);
        System.out.println("Student rollNo is:" +rollNo);
        System.out.println("Student grade is: "+grade);
    }
    public static void main(String[] args) {
        Student s= new Student("Shivam Yadav",25,"A++");
        s.viewDetails();
    }

    
}
