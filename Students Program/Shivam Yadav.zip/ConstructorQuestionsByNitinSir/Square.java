/*Write a Java program to create a class called Square with an attribute side. Create
a constructor to initialize the side and calculate the area */
package ConstructorQuestionsByNitinSir;

public class Square {
    int side;

    Square()
    {
        side=2;

    }
    void area()
    {
        int area=side*side;
        System.out.println("Area is:"+area);
    }

    public static void main(String[] args) {
        Square s=new Square();
        s.area();
    }
    
}
