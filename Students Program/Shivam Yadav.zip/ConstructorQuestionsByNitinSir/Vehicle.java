/*Write a Java program to create a class called Vehicle with attributes type and
speed. Create a no-argument constructor with default values and print vehicle
detail */
package ConstructorQuestionsByNitinSir;

public class Vehicle {
    String type;
    int speed;

    Vehicle()
    {
        type="Four wheeler";
        speed=30;
    }
     void print()
     {
        System.out.println("Your Vahicle is:"+type);
         System.out.println("Speed is "+speed+" km");
     }

     public static void main(String[] args) {
        Vehicle v= new Vehicle();
        v.print();
     }
    
}
