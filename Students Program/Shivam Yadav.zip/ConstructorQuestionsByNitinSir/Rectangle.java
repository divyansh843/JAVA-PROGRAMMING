/*Write a Java program to create a class called Rectangle with attributes length
and width. Create a constructor to initialize these attributes and calculate the
area. */
package ConstructorQuestionsByNitinSir;

public class Rectangle {
    int length;
    int width;

    Rectangle()
    {
        length=10;
        width=20;

    }
    void area()
    {
       int area=length*width;
       System.out.println("Area is: "+area);
    }
    public static void main(String[] args) {
        Rectangle r=new Rectangle();
                  r.area();
    }
    
    
}
