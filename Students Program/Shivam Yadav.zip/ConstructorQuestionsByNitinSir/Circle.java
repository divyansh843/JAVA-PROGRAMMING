/*Write a Java program to create a class called Circle with a radius attribute.
Create a constructor to initialize radius and calculate the circumference. */
package ConstructorQuestionsByNitinSir;

public class Circle {
    double radius;
    double pi=3.14;

    Circle()
    {
        radius=45;

    }
    void circumference()
    {
        double c=2*pi*radius;
        System.out.println("Circumference is: "+c);
    } 
    public static void main(String[] args) {
        Circle c=new Circle();
        c.circumference();
    }

    
}
