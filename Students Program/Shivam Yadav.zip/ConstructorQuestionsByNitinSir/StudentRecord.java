/*Write a Java program to create a class called StudentRecord with attributes name,
rollNo, and marks. Create a constructor to initialize these attributes and print
details */
package ConstructorQuestionsByNitinSir;

public class StudentRecord {
    
}
