/*Write a Java program to create a class called Customer with attributes name and
customerId. Create a constructor to initialize these attributes and print customer
details */
package ConstructorQuestionsByNitinSir;

public class Customer {
    String name;
    int customerId;

    Customer()
    {
        name="Mahak Gupta ";
        customerId=19;

    }

    void display()
    {
        System.out.println("Customer name is:"+name);
        System.out.println("CustomerId is:"+customerId);
    }

    public static void main(String[] args) {
        Customer c=new Customer();
        c.display();
    }
    
}
