/*Write a Java program to create a class called Item with attributes name and price.
Create a constructor to initialize these attributes and print item details */
package ConstructorQuestionsByNitinSir;

public class Item {
    
}
