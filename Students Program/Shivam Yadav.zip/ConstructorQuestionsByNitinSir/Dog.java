/*Write a Java program to create a class called Dog with attributes name and breed.
Create a no-argument constructor with default values and print the dog details */
package ConstructorQuestionsByNitinSir;

public class Dog {
    String name;
    String breed;

    Dog()
    {
        name="Sloopy";
        breed="Senior";
    }
    void dogDetails()
    {
        System.out.println("My dog is:"+name);
        System.out.println("Dog breed is:"+breed);
    }
    public static void main(String[] args) {
        Dog s=new Dog();
        s.dogDetails();
    }
}
