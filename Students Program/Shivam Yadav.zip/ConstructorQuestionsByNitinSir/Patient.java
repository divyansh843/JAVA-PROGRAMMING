/*Write a Java program to create a class called Patient with attributes name and
patientId. Create a constructor to initialize these attributes and display patient
details */
package ConstructorQuestionsByNitinSir;

public class Patient {
    String name;
    int patientId;

    Patient()
    {
        name="Deepanshu Yadav";
        patientId=44;

    }

    void display()
    {
        System.out.println("Patient name is:"+name);
        System.out.println("Patient id is:"+patientId);
    }

    public static void main(String[] args) {
        
        Patient p=new Patient();
        p.display();
    }
    
}
