/*Write a Java program to create a class called Cube with an attribute side. Create
a constructor to initialize the side and calculate the volume */
package ConstructorQuestionsByNitinSir;

public class Cube {
    
}
