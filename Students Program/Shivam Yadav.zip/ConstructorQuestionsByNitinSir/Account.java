/*Write a Java program to create a class called Account with attributes accountHolder
and balance. Create a constructor to initialize these attributes and display account
details */
package ConstructorQuestionsByNitinSir;

public class Account {

    
    
}
