/*VWrite a Java program to create a class called Employee with attributes name and
id. Create a constructor to initialize these attributes and print employee details. */
package ConstructorQuestionsByNitinSir;

public class Employee {
    String name;
    int id;

    Employee()
    {
        name="Shivam Yadav";
        id=25;
    }
    void employeeDetails()
    {
        System.out.println("Employee name is: "+name);
        System.out.println("Employee id is: "+id);
    }
    public static void main(String[] args) {
        Employee e=new Employee();
        e.employeeDetails();
    }
    
}
