/*Write a Java program to create a class called Cylinder with attributes radius
and height. Create a constructor to initialize these attributes and calculate the
volume */
package ConstructorQuestionsByNitinSir;

public class Cylinder {
    
}
