/*Write a Java program to create a class called Phone with attributes brand and
model. Create a constructor to initialize these attributes and print phone details */
package ConstructorQuestionsByNitinSir;

public class Phone {
    String brand;
    String model;

    Phone()
    {
        brand="Nokia";
        model="5p";
    }
    void display()
    {
        System.out.println("phone brand is :"+brand);
        System.out.println("Phone model is:"+model);
    }

    public static void main(String[] args) {
        
        Phone p=new Phone();
        p.display();
    }
}
