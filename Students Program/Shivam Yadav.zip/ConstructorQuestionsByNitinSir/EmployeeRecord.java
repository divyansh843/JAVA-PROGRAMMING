/*Write a Java program to create a class called EmployeeRecord with attributes name,
id, and department. Create a constructor to initialize these attributes and display
them */
package ConstructorQuestionsByNitinSir;

public class EmployeeRecord {
    String name;
    int id;
    String department;

    EmployeeRecord()
    {
        name="Chandani yadav";
        id=54;
        department="CSE";
    }
    
    void display()
    {
        System.out.println("Employee name is:"+name);
                System.out.println("Employee id is:"+id);
                        System.out.println("Employee department:"+department);


    }
    public static void main(String[] args) {
        EmployeeRecord e=new EmployeeRecord();
        e.display();
    }
}
