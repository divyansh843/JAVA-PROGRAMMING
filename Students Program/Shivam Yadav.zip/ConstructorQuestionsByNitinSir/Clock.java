/*Write a Java program to create a class called Clock with attributes hours and
minutes. Create a constructor to initialize these attributes and display the time */
package ConstructorQuestionsByNitinSir;

public class Clock {

    int hours;
    int minutes;

    Clock()
    {
        hours=12;
        minutes=15;
    }

    void displayTime()
    {
        System.out.println("Time is: "+hours+":"+minutes);
    }

    public static void main(String[] args) {
        Clock c=new Clock();
        c.displayTime();
    }
    
}
