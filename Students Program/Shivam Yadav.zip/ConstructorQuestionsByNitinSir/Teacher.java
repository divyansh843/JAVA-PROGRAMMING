/*Write a Java program to create a class called Teacher with attributes name and
subject. Create a constructor to initialize these attributes and display teacher
details */
package ConstructorQuestionsByNitinSir;

public class Teacher {
     String name;
     String subject;

     Teacher()
     {
        name="Sumit Sahjada";
        subject="love";
     }
    
     void display()
     {
        System.out.println("Teacher is:"+name);
        System.out.println("Subject is:"+subject);
     }

     public static void main(String[] args) {
        Teacher t=new Teacher();
        t.display();
     }
}
