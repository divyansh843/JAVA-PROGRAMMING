/*1. Write a Java program to create a class called Car with attributes brand and model.
Create a constructor to initialize these attributes and print the car details. */
package ConstructorQuestionsByNitinSir;

public class Car {
     String brand;
     String model;

     Car()
     {
        brand="Nissan";
        model="GT-R";
     }
     void ShowDetails()
     {
        System.out.println("Car brand is: "+brand);
        System.out.println("Car model is: "+model);
     }
     public static void main(String[] args) {
        Car c=new Car();
        c.ShowDetails();
     }
    
}
