/* Write a Java program to create a class called Bicycle with attributes brand and
speed. Create a no-argument constructor with default values and display bicycle
detail */
package ConstructorQuestionsByNitinSir;

public class Bicycle {
    
}
