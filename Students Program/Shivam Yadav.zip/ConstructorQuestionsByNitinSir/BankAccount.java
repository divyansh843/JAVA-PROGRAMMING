/*Write a Java program to create a class called BankAccount with attributes accountNumber
and balance. Create a constructor to initialize these attributes and print account
details */
package ConstructorQuestionsByNitinSir;

public class BankAccount {
    long accountNo;
    long bal;

    BankAccount()
    {
        accountNo=987654675687l;
        bal=28000;

    }

    void BankDetails()
    {
        System.out.println("Your No is:"+accountNo);
        System.out.println("Your bank balance is:"+bal);
    }
    
    public static void main(String[] args) {
        BankAccount ba=new BankAccount();
        ba.BankDetails();
    }
}
