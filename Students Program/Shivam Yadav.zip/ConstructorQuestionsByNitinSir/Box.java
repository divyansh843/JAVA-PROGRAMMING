/*Write a Java program to create a class called Box with attributes length, width,
and height. Create a constructor to initialize these attributes and calculate the
volume */
package ConstructorQuestionsByNitinSir;

public class Box {
      float length;
      float width;
      float height;

      Box()
      {
        length=20;
        width=10;
        height=25;
      }

      void display()
      {
        float volume=length*width*height;
        System.out.println("Volume is:"+volume);
      }

      public static void main(String[] args) {
        
        Box b=new Box();
        b.display();

      }
    
}
