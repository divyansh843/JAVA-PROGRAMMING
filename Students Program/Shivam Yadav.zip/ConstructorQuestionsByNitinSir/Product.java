/*Write a Java program to create a class called Product with attributes name, price,
and quantity. Create a constructor to initialize these attributes and calculate total
cost */
package ConstructorQuestionsByNitinSir;

public class Product {
    String name;
    int price;
    int quantity;

    Product()
    {
        name="iphone";
        price=850000;
        quantity=4;
    }

    void display()
    {
        System.out.println("Product Name is:"+name);
        System.out.println("Product price is:"+price);
        System.out.println("product quantity is:"+quantity);
    }

    public static void main(String[] args) {
        Product p=new Product();
        p.display();
    }
    
}
