/*Write a Java program to create a class called Mobile with attributes brand and
price. Create a constructor to initialize these attributes and display mobile details */
package ConstructorQuestionsByNitinSir;

public class Mobile {
      String brand;
      int price;

      Mobile()
      {
        brand="Vivo";
        price=17000;
      }

      void display(){

        System.out.println("Your brand is:"+brand);
        System.out.println("Mobile price is:"+price);


      }
      public static void main(String[] args) {
        Mobile m=new Mobile();
        m.display();

      }

    
}
