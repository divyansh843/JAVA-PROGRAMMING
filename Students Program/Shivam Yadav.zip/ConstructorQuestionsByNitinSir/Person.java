/*Write a Java program to create a class called Person with attributes name and age.
Create a constructor to initialize these attributes and print the persons details */
package ConstructorQuestionsByNitinSir;

public class Person {
    String name;
    int age;

    Person()
    {
        name="Sandeep Kumar";
        age=20;

    }
    void display()
    {
        System.out.println("Name is :"+name);
        System.out.println("Person age is:"+age);
    }

    public static void main(String[] args) {
        Person p=new Person();
        p.display();
    }

    
}
