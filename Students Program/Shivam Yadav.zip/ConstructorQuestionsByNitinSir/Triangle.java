/*. Write a Java program to create a class called Triangle with attributes base and
height. Create a constructor to initialize these attributes and calculate the area */
package ConstructorQuestionsByNitinSir;

public class Triangle {
    float base;
    float height;
    Triangle()
    {
        base=40f;
        height=35f;

    }
    void area()
    {
        float area= 0.5f*base*height;
        System.out.println("Your area is:"+area);
    }
    public static void main(String[] args) {
        Triangle t=new Triangle();
        t.area();

    }

    
}
