/*Write a Java program to create a class called Room with attributes length and
width. Create a constructor to initialize these attributes and calculate the area */
package ConstructorQuestionsByNitinSir;

public class Room {
    float length;
    float width;

    Room()
    {
        length=30;
        width=20;

    }

    void area()
    {
        float area=length*width;
        System.out.println("Area is :"+area);
    }

    public static void main(String[] args) {
        Room r=new Room();
        r.area();
    }
    
}
