/*Write a Java program to create a class called Library with attributes bookTitle
and bookId. Create a no-argument constructor with default values and print library
details */
package ConstructorQuestionsByNitinSir;

public class Library {
    String bookTitle;
    int bookId;

    Library()
    {
        bookTitle="let us java";
        bookId=546534;
    }

     void display()
      {
        System.out.println("Your book title is :"+bookTitle);
        System.out.println("Your bookid is:"+bookId);
      }
   
      public static void main(String[] args) {
        Library l=new Library();
        l.display();
      }
    
}
