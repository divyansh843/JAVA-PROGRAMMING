/*Write a Java program to create a class called Book with attributes title and
author. Create a no-argument constructor that sets default values and prints the
book details. */
package ConstructorQuestionsByNitinSir;

public class Book {
    String title;
    String author;

    Book()
    {
        title="Gunaho ke devta";
        author="Dharamvir bharti";
    }
    void viewDetails()
    {
        System.out.println("Book title is:"+ title);
        System.out.println("Book author is:"+author);
    }
    public static void main(String[] args) {
        Book b=new Book();
        b.viewDetails();
    }
    
}
