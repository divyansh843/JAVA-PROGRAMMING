/*Write a Java program to create a class called Laptop with attributes brand, model,
and price. Create a constructor to initialize these attributes and display them */
package ConstructorQuestionsByNitinSir;

public class Laptop {
    String brand;
    String model;
    double price;

    Laptop()
    {
        brand="Dell";
        model="Inspiron 13 5330:";
        price=85890;
    }
    void viewDetails()
    {
        System.out.println("Laptop brand is :"+brand);
        System.out.println("Laptop model is:"+model);
        System.out.println("Laptop price is:"+price);
    }
    public static void main(String[] args) {
        Laptop l=new Laptop();
        l.viewDetails();
    }

    
}
